// app/(site)/page.tsx or pages/index.tsx
import HeroMoon from "@/components/HeroMoon";
import "@/styles/hero.css";

export default function Page() {
  return (
    <main className="hero">
      <section>
        <h1>Your Vision, Engineered.</h1>
        <p>Senior engineers shipping production-ready software at startup speed.</p>
        <div className="hero-cta">
          <a className="btn-primary" href="/contact">Book a Free Call</a>
          <a className="btn-secondary" href="/portfolio">See Our Work</a>
        </div>
      </section>
      <HeroMoon />
    </main>
  );
}
