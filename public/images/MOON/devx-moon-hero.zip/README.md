# DevX Moon Hero Kit
Files you can drop into a Next.js site for a fast hero.

## Files
- /public/moon_hero_[512|768|1024|1536].{webp,png}
- /components/HeroMoon.tsx
- /styles/hero.css
- example.page.tsx

## Use
1. Copy `public/*` into your project's `public/` folder.
2. Copy `components/HeroMoon.tsx` and `styles/hero.css` into your project.
3. Import the component and CSS in your hero page.

## Performance
- WEBP is default. PNG is fallback.
- The `<picture>` uses `sizes` so the browser picks the smallest valid file.
- The hero image is marked `eager` and `fetchPriority=high` to help LCP.
- Keep the hero background dark-neutral for best contrast (#0b0f14 to #10141a).

## Optional: Preload
Add to `<head>` of the hero route:
<link rel="preload" as="image" href="/moon_hero_1024.webp"
      imagesrcset="/moon_hero_1536.webp 1536w, /moon_hero_1024.webp 1024w, /moon_hero_768.webp 768w, /moon_hero_512.webp 512w"
      imagesizes="(max-width: 768px) 60vw, (max-width: 1200px) 40vw, 35vw">

## Accessibility
- Keep `alt="Realistic Moon"`.
- Ensure text contrast against background meets WCAG AA.
