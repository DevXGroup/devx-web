// components/HeroMoon.tsx
// Drop-in hero Moon with optimal sources and accessibility
"use client";
import React from "react";

export default function HeroMoon({
  className = "",
  priority = true
}: { className?: string; priority?: boolean }) {
  return (
    <picture className={`hero-moon ${className}`}>
      <source srcSet="/moon_hero_1536.webp 1536w, /moon_hero_1024.webp 1024w, /moon_hero_768.webp 768w, /moon_hero_512.webp 512w" type="image/webp" />
      <img
        src="/moon_hero_1024.png"
        srcSet="/moon_hero_1536.png 1536w, /moon_hero_1024.png 1024w, /moon_hero_768.png 768w, /moon_hero_512.png 512w"
        sizes="(max-width: 768px) 60vw, (max-width: 1200px) 40vw, 35vw"
        width="1024"
        height="1024"
        alt="Realistic Moon"
        loading={priority ? "eager" : "lazy"}
        fetchPriority={priority ? "high" : "auto"}
        decoding="async"
      />
    </picture>
  );
}
